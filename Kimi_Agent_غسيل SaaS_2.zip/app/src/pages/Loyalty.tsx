import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";

import {
  Award,
  Crown,
  Star,
  Users,
  Gift,
  TrendingUp,
  Search,
  Phone,
  RefreshCw,
} from "lucide-react";

const tierConfig: Record<string, { color: string; bg: string; icon: React.ReactNode; next: string; threshold: number }> = {
  bronze: {
    color: "text-amber-700",
    bg: "bg-amber-100 dark:bg-amber-900/30",
    icon: <Award className="w-5 h-5" />,
    next: "Silver",
    threshold: 500,
  },
  silver: {
    color: "text-gray-600",
    bg: "bg-gray-100 dark:bg-gray-800",
    icon: <Star className="w-5 h-5" />,
    next: "Gold",
    threshold: 1000,
  },
  gold: {
    color: "text-yellow-600",
    bg: "bg-yellow-100 dark:bg-yellow-900/30",
    icon: <Crown className="w-5 h-5" />,
    next: "Platinum",
    threshold: 2000,
  },
  platinum: {
    color: "text-purple-600",
    bg: "bg-purple-100 dark:bg-purple-900/30",
    icon: <Crown className="w-5 h-5" />,
    next: "Max",
    threshold: 99999,
  },
};

export default function Loyalty() {
  const [search, setSearch] = useState("");
  const { data: members, isLoading, refetch } = trpc.loyalty.list.useQuery(
    { search: search || undefined }
  );
  const { data: stats } = trpc.loyalty.stats.useQuery();

  if (isLoading) {
    return (
      <div className="p-4 lg:p-6 space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Loyalty Program</h2>
          <p className="text-muted-foreground text-sm">Customer rewards and points management</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="bg-amber-50/50 dark:bg-amber-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <Users className="w-5 h-5 text-amber-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.totalMembers || 0}</p>
              <p className="text-xs text-muted-foreground">Members</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-purple-50/50 dark:bg-purple-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <Gift className="w-5 h-5 text-purple-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.totalPoints?.toLocaleString() || 0}</p>
              <p className="text-xs text-muted-foreground">Total Points</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-yellow-50/50 dark:bg-yellow-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <Crown className="w-5 h-5 text-yellow-600" />
            <div>
              <p className="text-2xl font-bold">
                {stats?.tierCounts?.find((t) => t.tier === "platinum")?.count || 0}
              </p>
              <p className="text-xs text-muted-foreground">Platinum</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-50/50 dark:bg-green-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <div>
              <p className="text-2xl font-bold">
                {stats?.tierCounts?.find((t) => t.tier === "gold")?.count || 0}
              </p>
              <p className="text-xs text-muted-foreground">Gold</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search by phone number..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Members Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="text-left py-3 px-4 font-medium">Member</th>
                  <th className="text-center py-3 px-4 font-medium">Tier</th>
                  <th className="text-center py-3 px-4 font-medium">Points</th>
                  <th className="text-center py-3 px-4 font-medium">Visits</th>
                  <th className="text-right py-3 px-4 font-medium">Total Earned</th>
                  <th className="text-center py-3 px-4 font-medium">Progress</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {members?.map((member) => {
                  const tier = tierConfig[member.tier] || tierConfig.bronze;
                  const progress = Math.min(100, (member.totalEarned / tier.threshold) * 100);
                  return (
                    <tr key={member.id} className="hover:bg-muted/30 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-9 h-9 rounded-full flex items-center justify-center ${tier.bg} ${tier.color}`}>
                            {tier.icon}
                          </div>
                          <div>
                            <p className="font-medium">{member.customerName || "Unknown"}</p>
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {member.customerPhone}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge className={`${tier.bg} ${tier.color} capitalize`}>
                          {member.tier}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-center font-semibold">
                        {member.points.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {member.visits}
                      </td>
                      <td className="py-3 px-4 text-right font-medium">
                        {member.totalEarned.toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <div className="w-full max-w-[120px] mx-auto">
                          <Progress value={progress} className="h-1.5" />
                          <p className="text-[10px] text-muted-foreground text-center mt-1">
                            {progress.toFixed(0)}% to {tier.next}
                          </p>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {members?.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              No loyalty members found.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
