import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

import {
  Bell,
  CheckCheck,
  CalendarCheck,
  CircleDollarSign,
  Users,
  Star,
  AlertTriangle,
  Megaphone,
  Clock,
} from "lucide-react";

const typeIcons: Record<string, React.ReactNode> = {
  booking: <CalendarCheck className="w-4 h-4 text-blue-600" />,
  payment: <CircleDollarSign className="w-4 h-4 text-green-600" />,
  worker: <Users className="w-4 h-4 text-violet-600" />,
  system: <AlertTriangle className="w-4 h-4 text-amber-600" />,
  review: <Star className="w-4 h-4 text-amber-600" />,
  promotion: <Megaphone className="w-4 h-4 text-pink-600" />,
};

const typeColors: Record<string, string> = {
  booking: "bg-blue-50 text-blue-700",
  payment: "bg-green-50 text-green-700",
  worker: "bg-violet-50 text-violet-700",
  system: "bg-amber-50 text-amber-700",
  review: "bg-amber-50 text-amber-700",
  promotion: "bg-pink-50 text-pink-700",
};

export default function Notifications() {
  const { data: notifications, isLoading, refetch } = trpc.notification.list.useQuery({ limit: 50 });
  const markAllRead = trpc.notification.markAllRead.useMutation({ onSuccess: () => refetch() });
  const markRead = trpc.notification.markRead.useMutation({ onSuccess: () => refetch() });

  if (isLoading) {
    return (
      <div className="p-4 lg:p-6 space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Notifications</h2>
          <p className="text-muted-foreground text-sm">Stay updated with your business</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => markAllRead.mutate()}>
          <CheckCheck className="w-4 h-4 mr-2" />
          Mark All Read
        </Button>
      </div>

      {/* Notifications List */}
      <Card>
        <CardContent className="p-0 divide-y divide-border">
          {notifications?.map((notification) => (
            <div
              key={notification.id}
              className={`flex items-start gap-4 p-4 hover:bg-muted/30 transition-colors cursor-pointer ${
                notification.isRead === "false" ? "bg-blue-50/30 dark:bg-blue-950/10" : ""
              }`}
              onClick={() => {
                if (notification.isRead === "false") {
                  markRead.mutate({ id: notification.id });
                }
              }}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                typeColors[notification.type]?.split(" ")[0] || "bg-gray-100"
              }`}>
                {typeIcons[notification.type] || <Bell className="w-4 h-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm">{notification.title}</p>
                  {notification.isRead === "false" && (
                    <span className="w-2 h-2 bg-blue-500 rounded-full shrink-0" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">{notification.message}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-[10px]">
                    {notification.type}
                  </Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(notification.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {notifications?.length === 0 && (
        <div className="text-center py-12">
          <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No notifications yet.</p>
        </div>
      )}
    </div>
  );
}
