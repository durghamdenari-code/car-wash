import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";

import {
  MessageCircle,
  Send,
  CheckCheck,
  Zap,
  Shield,
  TrendingUp,
} from "lucide-react";

const chatFlow = [
  {
    id: 1,
    role: "bot",
    message: "Hello! Welcome to WashyPro. How can I help you today?",
    options: ["Book a wash", "View services", "Check pricing", "My bookings"],
  },
  {
    id: 2,
    role: "user",
    message: "Book a wash",
  },
  {
    id: 3,
    role: "bot",
    message: "Great! What type of vehicle do you have?",
    options: ["Sedan", "SUV", "Hatchback", "Truck"],
  },
  {
    id: 4,
    role: "user",
    message: "Sedan",
  },
  {
    id: 5,
    role: "bot",
    message: "Which service would you like?",
    options: ["Quick Wash - EGP 50", "Full Exterior - EGP 80", "Full Package - EGP 150", "Premium - EGP 250"],
  },
  {
    id: 6,
    role: "user",
    message: "Full Package - EGP 150",
  },
  {
    id: 7,
    role: "bot",
    message: "Please share your location so we can assign the nearest worker.",
    options: ["Share Location"],
  },
  {
    id: 8,
    role: "bot",
    message: "Booking confirmed! Booking #WASH-2024-016. Your washer Ahmed will arrive in ~25 minutes.",
  },
];

export default function Whatsapp() {
  const [botEnabled, setBotEnabled] = useState(true);

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">WhatsApp Bot</h2>
          <p className="text-muted-foreground text-sm">AI-powered booking assistant</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">Bot Status</span>
          <Switch checked={botEnabled} onCheckedChange={setBotEnabled} />
          <Badge className={botEnabled ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
            {botEnabled ? "Online" : "Offline"}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Preview */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3 border-b">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-base">WashyPro Bot</CardTitle>
                <p className="text-xs text-green-600 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                  Online
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[500px] overflow-y-auto p-4 space-y-4 bg-[#f0f2f5] dark:bg-[#0c0c0c]">
              {chatFlow.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${
                      msg.role === "user"
                        ? "bg-blue-500 text-white rounded-br-sm"
                        : "bg-white dark:bg-zinc-800 rounded-bl-sm shadow-sm"
                    }`}
                  >
                    <p className="text-sm">{msg.message}</p>
                    {msg.options && (
                      <div className="mt-2 space-y-1.5">
                        {msg.options.map((opt) => (
                          <button
                            key={opt}
                            className="block w-full text-left text-sm px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors border border-white/20"
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    )}
                    <p className={`text-[10px] mt-1 ${msg.role === "user" ? "text-blue-200" : "text-muted-foreground"}`}>
                      {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-3 border-t bg-card flex items-center gap-2">
              <Input placeholder="Type a message..." className="flex-1" />
              <Button size="icon" className="rounded-full bg-green-500 hover:bg-green-600">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Bot Stats & Settings */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Bot Performance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-blue-600" />
                  <span className="text-sm">Conversations Today</span>
                </div>
                <span className="font-bold">48</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCheck className="w-4 h-4 text-green-600" />
                  <span className="text-sm">Bookings Created</span>
                </div>
                <span className="font-bold">15</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-600" />
                  <span className="text-sm">Avg Response Time</span>
                </div>
                <span className="font-bold">&lt;2s</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-violet-600" />
                  <span className="text-sm">Success Rate</span>
                </div>
                <span className="font-bold">94%</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quick Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">Auto-Reply</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Location Request</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Photo Sharing</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Rating Request</span>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 dark:bg-green-950/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium">WhatsApp API</p>
                  <p className="text-xs text-muted-foreground">Connected & Healthy</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
