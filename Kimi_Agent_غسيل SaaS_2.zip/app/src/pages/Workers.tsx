import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import {
  Search,
  Users,
  Star,
  Briefcase,
  Truck,
  Phone,
  Mail,
  Plus,
  RefreshCw,
  CircleDot,
} from "lucide-react";

const statusColors: Record<string, string> = {
  active: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  inactive: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
  busy: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  offline: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

export default function Workers() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedWorker, setSelectedWorker] = useState<number | null>(null);

  const { data: workers, isLoading, refetch } = trpc.worker.list.useQuery(
    { search: search || undefined, status: statusFilter === "all" ? undefined : statusFilter }
  );
  const { data: stats } = trpc.worker.stats.useQuery();
  const { data: workerDetail } = trpc.worker.getById.useQuery(
    { id: selectedWorker! },
    { enabled: !!selectedWorker }
  );

  if (isLoading) {
    return (
      <div className="p-4 lg:p-6 space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Workers</h2>
          <p className="text-muted-foreground text-sm">Manage your cleaning crew</p>
        </div>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Worker
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="bg-blue-50/50 dark:bg-blue-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <Users className="w-5 h-5 text-blue-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.total || 0}</p>
              <p className="text-xs text-muted-foreground">Total Workers</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-50/50 dark:bg-green-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <CircleDot className="w-5 h-5 text-green-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.active || 0}</p>
              <p className="text-xs text-muted-foreground">Active Now</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-amber-50/50 dark:bg-amber-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <Star className="w-5 h-5 text-amber-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.avgRating?.toFixed(1) || "0.0"}</p>
              <p className="text-xs text-muted-foreground">Avg Rating</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-violet-50/50 dark:bg-violet-950/20">
          <CardContent className="p-4 flex items-center gap-3">
            <Briefcase className="w-5 h-5 text-violet-600" />
            <div>
              <p className="text-2xl font-bold">{workers?.reduce((acc, w) => acc + (w.totalJobs || 0), 0) || 0}</p>
              <p className="text-xs text-muted-foreground">Total Jobs</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search workers..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="busy">Busy</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="offline">Offline</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={() => refetch()}>
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </Card>

      {/* Workers Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {workers?.map((worker) => (
          <Card key={worker.id} className="hover:shadow-md transition-shadow cursor-pointer group" onClick={() => setSelectedWorker(worker.id)}>
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-lg font-bold">
                    {worker.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold">{worker.name}</p>
                    <p className="text-xs text-muted-foreground">{worker.vehicleType}</p>
                  </div>
                </div>
                <Badge className={statusColors[worker.status]}>
                  {worker.status}
                </Badge>
              </div>

              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-3.5 h-3.5" />
                  <span>{worker.phone}</span>
                </div>
                {worker.email && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="w-3.5 h-3.5" />
                    <span className="truncate">{worker.email}</span>
                  </div>
                )}
                {worker.vehiclePlate && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Truck className="w-3.5 h-3.5" />
                    <span className="font-mono text-xs">{worker.vehiclePlate}</span>
                  </div>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-border flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span className="font-semibold text-sm">{worker.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>{worker.totalJobs} jobs</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {workers?.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          No workers found matching your criteria.
        </div>
      )}

      {/* Worker Detail Dialog */}
      <Dialog open={!!selectedWorker} onOpenChange={() => setSelectedWorker(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Worker Profile</DialogTitle>
          </DialogHeader>
          {workerDetail && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-2xl font-bold">
                  {workerDetail.name.charAt(0)}
                </div>
                <div>
                  <p className="text-xl font-bold">{workerDetail.name}</p>
                  <Badge className={statusColors[workerDetail.status]}>
                    {workerDetail.status}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-muted p-3 rounded-lg text-center">
                  <Star className="w-5 h-5 text-amber-500 mx-auto mb-1" />
                  <p className="text-xl font-bold">{workerDetail.rating}</p>
                  <p className="text-xs text-muted-foreground">Rating</p>
                </div>
                <div className="bg-muted p-3 rounded-lg text-center">
                  <Briefcase className="w-5 h-5 text-blue-500 mx-auto mb-1" />
                  <p className="text-xl font-bold">{workerDetail.totalJobs}</p>
                  <p className="text-xs text-muted-foreground">Jobs Done</p>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>{workerDetail.phone}</span>
                </div>
                {workerDetail.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span>{workerDetail.email}</span>
                  </div>
                )}
                {workerDetail.vehicleType && (
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-muted-foreground" />
                    <span>{workerDetail.vehicleType} ({workerDetail.vehiclePlate})</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
