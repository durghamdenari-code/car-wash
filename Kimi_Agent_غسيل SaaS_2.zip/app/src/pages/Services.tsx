import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

import {
  SprayCan,
  Car,
  Armchair,
  Sparkles,
  Crown,
  Cog,
  Droplets,
  Gem,
  Clock,
  Tag,
  Plus,
} from "lucide-react";

const iconMap: Record<string, React.ReactNode> = {
  SprayCan: <SprayCan className="w-6 h-6" />,
  Car: <Car className="w-6 h-6" />,
  Armchair: <Armchair className="w-6 h-6" />,
  Sparkles: <Sparkles className="w-6 h-6" />,
  Crown: <Crown className="w-6 h-6" />,
  Cog: <Cog className="w-6 h-6" />,
  Droplets: <Droplets className="w-6 h-6" />,
  Gem: <Gem className="w-6 h-6" />,
};

const categoryLabels: Record<string, string> = {
  exterior: "Exterior",
  interior: "Interior",
  full: "Full Package",
  premium: "Premium",
  detailing: "Detailing",
};

const categoryColors: Record<string, string> = {
  exterior: "bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-300",
  interior: "bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300",
  full: "bg-violet-50 text-violet-700 dark:bg-violet-950/30 dark:text-violet-300",
  premium: "bg-pink-50 text-pink-700 dark:bg-pink-950/30 dark:text-pink-300",
  detailing: "bg-cyan-50 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-300",
};

export default function Services() {
  const { data: services, isLoading } = trpc.service.list.useQuery();
  const { data: count } = trpc.service.count.useQuery();

  if (isLoading) {
    return (
      <div className="p-4 lg:p-6 space-y-4">
        <Skeleton className="h-10 w-64" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Services</h2>
          <p className="text-muted-foreground text-sm">{count} services available</p>
        </div>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Service
        </Button>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {services?.map((service) => (
          <Card key={service.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
            <div className="h-2" style={{ backgroundColor: service.color || "#3b82f6" }} />
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-white"
                  style={{ backgroundColor: service.color || "#3b82f6" }}
                >
                  {iconMap[service.icon || ""] || <Sparkles className="w-6 h-6" />}
                </div>
                <Badge variant="outline" className={categoryColors[service.category] || "bg-gray-100"}>
                  {categoryLabels[service.category] || service.category}
                </Badge>
              </div>

              <h3 className="mt-4 font-semibold text-lg">{service.name}</h3>
              {service.nameAr && (
                <p className="text-sm text-muted-foreground" dir="rtl">{service.nameAr}</p>
              )}
              {service.description && (
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{service.description}</p>
              )}

              <div className="mt-4 pt-4 border-t border-border space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <Tag className="w-4 h-4" />
                    <span>Price</span>
                  </div>
                  <p className="font-bold text-lg">EGP {parseFloat(service.basePrice).toFixed(0)}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>Duration</span>
                  </div>
                  <p className="text-sm font-medium">{service.duration} min</p>
                </div>
              </div>

              <div className="mt-3 flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">Edit</Button>
                <Button variant="outline" size="sm" className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50">
                  {service.isActive === "true" ? "Deactivate" : "Activate"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
