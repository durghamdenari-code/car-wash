import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router";

import {
  CalendarCheck,
  Users,
  Star,
  Wallet,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Car,
  MapPin,
  CircleDollarSign,
} from "lucide-react";

export default function Home() {
  const { data: stats, isLoading: statsLoading } = trpc.analytics.dashboard.useQuery();
  const { data: recentBookings, isLoading: bookingsLoading } = trpc.booking.recent.useQuery({ limit: 8 });

  if (statsLoading || bookingsLoading) {
    return (
      <div className="p-4 lg:p-6 space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
        <Skeleton className="h-80" />
      </div>
    );
  }

  const statCards = [
    {
      title: "Today's Bookings",
      value: stats?.todayBookings || 0,
      icon: CalendarCheck,
      color: "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300",
      iconColor: "text-blue-600",
      link: "/bookings",
    },
    {
      title: "Active Workers",
      value: stats?.activeWorkers || 0,
      suffix: ` / ${stats?.totalWorkers || 0}`,
      icon: Users,
      color: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
      iconColor: "text-emerald-600",
      link: "/workers",
    },
    {
      title: "Avg Rating",
      value: stats?.averageRating?.toFixed(1) || "0.0",
      icon: Star,
      color: "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
      iconColor: "text-amber-600",
      link: "/reviews",
    },
    {
      title: "Today's Revenue",
      value: `EGP ${(stats?.todayRevenue || 0).toLocaleString()}`,
      icon: Wallet,
      color: "bg-violet-50 text-violet-700 dark:bg-violet-950 dark:text-violet-300",
      iconColor: "text-violet-600",
      link: "/analytics",
    },
  ];

  const statusColors: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
    confirmed: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
    assigned: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
    in_progress: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
    completed: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
    cancelled: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
    no_show: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground text-sm mt-1">
            Welcome back! Here's what's happening today.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to="/bookings">
              View All Bookings
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <Link key={card.title} to={card.link}>
            <Card className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-transparent hover:border-l-blue-500">
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                    <p className="text-2xl font-bold">
                      {card.value}
                      {card.suffix && <span className="text-sm font-normal text-muted-foreground">{card.suffix}</span>}
                    </p>
                  </div>
                  <div className={`p-3 rounded-xl ${card.color}`}>
                    <card.icon className={`w-6 h-6 ${card.iconColor}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Quick Status */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100/50 dark:from-yellow-950/30 dark:to-yellow-900/20 border-yellow-200/50">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.pendingBookings || 0}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-orange-50 to-orange-100/50 dark:from-orange-950/30 dark:to-orange-900/20 border-orange-200/50">
          <CardContent className="p-4 flex items-center gap-3">
            <Clock className="w-5 h-5 text-orange-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.inProgressBookings || 0}</p>
              <p className="text-xs text-muted-foreground">In Progress</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-50 to-green-100/50 dark:from-green-950/30 dark:to-green-900/20 border-green-200/50">
          <CardContent className="p-4 flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-green-600" />
            <div>
              <p className="text-2xl font-bold">{stats?.completedBookings || 0}</p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-violet-50 to-violet-100/50 dark:from-violet-950/30 dark:to-violet-900/20 border-violet-200/50">
          <CardContent className="p-4 flex items-center gap-3">
            <CircleDollarSign className="w-5 h-5 text-violet-600" />
            <div>
              <p className="text-2xl font-bold">EGP {(stats?.totalRevenue || 0).toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Total Revenue</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Bookings */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Recent Bookings</CardTitle>
              <p className="text-sm text-muted-foreground">Latest wash requests from WhatsApp</p>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/bookings">View All</Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {recentBookings?.map((booking) => (
              <div
                key={booking.id}
                className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-950/50 flex items-center justify-center shrink-0">
                  <Car className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium truncate">{booking.customerName}</p>
                    <Badge variant="outline" className="text-[10px] shrink-0">
                      {booking.bookingNumber}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                    <span className="flex items-center gap-1">
                      <Car className="w-3 h-3" />
                      {booking.carType}
                    </span>
                    {booking.address && (
                      <span className="flex items-center gap-1 truncate">
                        <MapPin className="w-3 h-3" />
                        {booking.address}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <Badge className={statusColors[booking.status] || "bg-gray-100"}>
                    {booking.status.replace("_", " ")}
                  </Badge>
                  <p className="text-xs font-semibold mt-1">EGP {booking.totalAmount}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Additional Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">WhatsApp Bot Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
              <span className="text-sm font-medium">Online & Responding</span>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Bot is actively handling customer inquiries and bookings via WhatsApp.
            </p>
            <div className="mt-4 flex gap-4 text-sm">
              <div>
                <p className="font-semibold">95%</p>
                <p className="text-xs text-muted-foreground">Response Rate</p>
              </div>
              <div>
                <p className="font-semibold">&lt;2min</p>
                <p className="text-xs text-muted-foreground">Avg Response</p>
              </div>
              <div>
                <p className="font-semibold">{stats?.todayBookings || 0}</p>
                <p className="text-xs text-muted-foreground">Today</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Loyalty Program</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-50 dark:bg-amber-950/50 flex items-center justify-center">
                  <Star className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">{stats?.totalLoyaltyMembers || 0} Active Members</p>
                  <p className="text-xs text-muted-foreground">Across 4 tiers</p>
                </div>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/loyalty">Manage</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
