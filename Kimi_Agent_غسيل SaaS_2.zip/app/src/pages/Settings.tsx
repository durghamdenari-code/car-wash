import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import {
  Building2,
  CreditCard,
  MessageCircle,
  Bell,
  Save,
} from "lucide-react";

export default function Settings() {
  const [autoAssign, setAutoAssign] = useState(true);
  const [whatsappEnabled, setWhatsappEnabled] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Settings</h2>
        <p className="text-muted-foreground text-sm">Manage your business preferences</p>
      </div>

      <Tabs defaultValue="business" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="business">
            <Building2 className="w-4 h-4 mr-2" />
            Business
          </TabsTrigger>
          <TabsTrigger value="whatsapp">
            <MessageCircle className="w-4 h-4 mr-2" />
            WhatsApp
          </TabsTrigger>
          <TabsTrigger value="payments">
            <CreditCard className="w-4 h-4 mr-2" />
            Payments
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="w-4 h-4 mr-2" />
            Alerts
          </TabsTrigger>
        </TabsList>

        {/* Business Settings */}
        <TabsContent value="business">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Business Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Business Name</Label>
                  <Input defaultValue="WashyPro Car Care" />
                </div>
                <div className="space-y-2">
                  <Label>Phone Number</Label>
                  <Input defaultValue="+201012345678" />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input defaultValue="info@washypro.com" />
                </div>
                <div className="space-y-2">
                  <Label>Website</Label>
                  <Input defaultValue="https://washypro.com" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Address</Label>
                <Input defaultValue="123 Business District, Cairo, Egypt" />
              </div>
              <div className="space-y-2">
                <Label>Business Description</Label>
                <textarea
                  className="w-full min-h-[80px] rounded-md border border-input bg-background px-3 py-2 text-sm"
                  defaultValue="Premium mobile car wash and detailing services at your doorstep."
                />
              </div>
              <Button>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-base">Operating Hours</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                  <div key={day} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <span className="font-medium">{day}</span>
                    <div className="flex items-center gap-2">
                      <Input type="time" defaultValue="09:00" className="w-24" />
                      <span>to</span>
                      <Input type="time" defaultValue="21:00" className="w-24" />
                      <Switch defaultChecked={day !== "Sunday"} />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* WhatsApp Settings */}
        <TabsContent value="whatsapp">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">WhatsApp Bot Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Enable WhatsApp Bot</Label>
                  <p className="text-xs text-muted-foreground">Allow customers to book via WhatsApp</p>
                </div>
                <Switch checked={whatsappEnabled} onCheckedChange={setWhatsappEnabled} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Auto-Reply to Inquiries</Label>
                  <p className="text-xs text-muted-foreground">Automatically respond to common questions</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Send Booking Confirmation</Label>
                  <p className="text-xs text-muted-foreground">Confirm bookings via WhatsApp message</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Send Completion Photos</Label>
                  <p className="text-xs text-muted-foreground">Share before/after photos with customers</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="space-y-2">
                <Label>API Token</Label>
                <div className="flex gap-2">
                  <Input type="password" defaultValue="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
                  <Button variant="outline">Update</Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Webhook URL</Label>
                <Input defaultValue="https://api.washypro.com/webhooks/whatsapp" readOnly />
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="text-sm font-semibold mb-2">Bot Status</h4>
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-sm">Connected & Responding</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Last synced: 2 minutes ago
                </p>
              </div>

              <Button>
                <Save className="w-4 h-4 mr-2" />
                Save WhatsApp Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Settings */}
        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Payment Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Payment Gateway</Label>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 border-blue-500 bg-blue-50">Paymob</Button>
                  <Button variant="outline" className="flex-1">Fawry</Button>
                  <Button variant="outline" className="flex-1">Stripe</Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>API Key</Label>
                <Input type="password" defaultValue="test_xxxxxxxxxxxxx" />
              </div>

              <div className="space-y-2">
                <Label>Integration ID</Label>
                <Input defaultValue="123456" />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Accept Cash Payments</Label>
                  <p className="text-xs text-muted-foreground">Allow customers to pay with cash</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Accept Card Payments</Label>
                  <p className="text-xs text-muted-foreground">Accept credit/debit card payments</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Accept Wallet Payments</Label>
                  <p className="text-xs text-muted-foreground">Vodafone Cash, Etisalat, etc.</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="space-y-2">
                <Label>Currency</Label>
                <Input defaultValue="EGP" readOnly />
              </div>

              <Button>
                <Save className="w-4 h-4 mr-2" />
                Save Payment Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Notification Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Push Notifications</Label>
                  <p className="text-xs text-muted-foreground">Receive push notifications for new bookings</p>
                </div>
                <Switch checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Notifications</Label>
                  <p className="text-xs text-muted-foreground">Send email alerts for important events</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>SMS Notifications</Label>
                  <p className="text-xs text-muted-foreground">Send SMS to workers for new assignments</p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Auto-Assign Workers</Label>
                  <p className="text-xs text-muted-foreground">Automatically assign nearest available worker</p>
                </div>
                <Switch checked={autoAssign} onCheckedChange={setAutoAssign} />
              </div>

              <div className="space-y-2">
                <Label>Notification Email</Label>
                <Input defaultValue="admin@washypro.com" />
              </div>

              <Button>
                <Save className="w-4 h-4 mr-2" />
                Save Notification Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
