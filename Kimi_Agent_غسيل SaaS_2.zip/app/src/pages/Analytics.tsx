import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

import {
  TrendingUp,
  CalendarCheck,
  CircleDollarSign,
  Users,
  Star,
  BarChart3,
} from "lucide-react";

export default function Analytics() {
  const { data: stats, isLoading: statsLoading } = trpc.analytics.dashboard.useQuery();
  const { data: revenue } = trpc.analytics.revenue.useQuery({ days: 7 });
  const { data: statusData } = trpc.analytics.bookingsByStatus.useQuery();

  if (statsLoading) {
    return (
      <div className="p-4 lg:p-6 space-y-4">
        <Skeleton className="h-10 w-64" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
        <Skeleton className="h-80" />
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800",
    confirmed: "bg-blue-100 text-blue-800",
    assigned: "bg-purple-100 text-purple-800",
    in_progress: "bg-orange-100 text-orange-800",
    completed: "bg-green-100 text-green-800",
    cancelled: "bg-red-100 text-red-800",
    no_show: "bg-gray-100 text-gray-800",
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Analytics & Reports</h2>
        <p className="text-muted-foreground text-sm">Business performance insights</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Total Bookings</p>
                <p className="text-2xl font-bold">{stats?.totalBookings?.toLocaleString() || 0}</p>
              </div>
              <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/50">
                <CalendarCheck className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-xs text-green-600">
              <TrendingUp className="w-3 h-3" />
              <span>+12% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold">EGP {(stats?.totalRevenue || 0).toLocaleString()}</p>
              </div>
              <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/50">
                <CircleDollarSign className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-xs text-green-600">
              <TrendingUp className="w-3 h-3" />
              <span>+8% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Active Workers</p>
                <p className="text-2xl font-bold">{stats?.activeWorkers || 0}</p>
              </div>
              <div className="p-3 rounded-lg bg-violet-50 dark:bg-violet-950/50">
                <Users className="w-6 h-6 text-violet-600" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground">
              <span>of {stats?.totalWorkers || 0} total workers</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Avg Rating</p>
                <p className="text-2xl font-bold">{stats?.averageRating?.toFixed(1) || "0.0"}</p>
              </div>
              <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/50">
                <Star className="w-6 h-6 text-amber-600" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3 text-xs text-green-600">
              <TrendingUp className="w-3 h-3" />
              <span>from {stats?.totalReviews || 0} reviews</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Revenue (Last 7 Days)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {revenue && revenue.length > 0 ? (
              <div className="space-y-3">
                {revenue.map((day) => {
                  const maxRevenue = Math.max(...revenue.map((d) => parseFloat(d.revenue)));
                  const barWidth = maxRevenue > 0 ? (parseFloat(day.revenue) / maxRevenue) * 100 : 0;
                  return (
                    <div key={day.date} className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground w-16 shrink-0">
                        {new Date(day.date).toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" })}
                      </span>
                      <div className="flex-1 h-6 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-blue-500 to-blue-400 rounded-full transition-all"
                          style={{ width: `${Math.max(barWidth, 5)}%` }}
                        />
                      </div>
                      <span className="text-xs font-medium w-16 text-right shrink-0">
                        EGP {parseFloat(day.revenue).toFixed(0)}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No revenue data for the selected period.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Booking Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Bookings by Status</CardTitle>
          </CardHeader>
          <CardContent>
            {statusData && statusData.length > 0 ? (
              <div className="space-y-3">
                {statusData.map((item) => {
                  const maxCount = Math.max(...statusData.map((d) => d.count));
                  const barWidth = maxCount > 0 ? (item.count / maxCount) * 100 : 0;
                  return (
                    <div key={item.status} className="flex items-center gap-3">
                      <Badge className={`${statusColors[item.status] || "bg-gray-100"} w-24 justify-center shrink-0 capitalize`}>
                        {item.status.replace("_", " ")}
                      </Badge>
                      <div className="flex-1 h-6 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-violet-500 to-violet-400 rounded-full transition-all"
                          style={{ width: `${Math.max(barWidth, 5)}%` }}
                        />
                      </div>
                      <span className="text-xs font-medium w-8 text-right shrink-0">{item.count}</span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No status data available.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Summary Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Performance Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-blue-600">{stats?.todayBookings || 0}</p>
              <p className="text-sm text-muted-foreground mt-1">Today's Bookings</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-green-600">EGP {(stats?.todayRevenue || 0).toLocaleString()}</p>
              <p className="text-sm text-muted-foreground mt-1">Today's Revenue</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-violet-600">{stats?.pendingBookings || 0}</p>
              <p className="text-sm text-muted-foreground mt-1">Pending</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-amber-600">{stats?.completedBookings || 0}</p>
              <p className="text-sm text-muted-foreground mt-1">Completed</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
