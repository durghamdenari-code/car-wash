import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findAllNotifications,
  findUnreadNotifications,
  createNotification,
  markAsRead,
  markAllAsRead,
  getUnreadCount,
} from "./queries/notifications";

export const notificationRouter = createRouter({
  list: publicQuery
    .input(z.object({ limit: z.number().default(50) }).optional())
    .query(({ input }) => findAllNotifications(input?.limit || 50)),

  unread: publicQuery.query(() => findUnreadNotifications()),

  create: publicQuery
    .input(
      z.object({
        title: z.string().min(1),
        message: z.string().min(1),
        type: z.enum(["booking", "payment", "worker", "system", "review", "promotion"]).optional(),
        recipientType: z.enum(["admin", "worker", "customer"]).optional(),
        recipientId: z.string().optional(),
        relatedId: z.number().optional(),
      })
    )
    .mutation(({ input }) => createNotification(input)),

  markRead: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => markAsRead(input.id)),

  markAllRead: publicQuery.mutation(() => markAllAsRead()),

  unreadCount: publicQuery.query(() => getUnreadCount()),
});
