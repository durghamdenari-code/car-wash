import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  getDashboardStats,
  getRevenueByDay,
  getBookingsByStatus,
} from "./queries/analytics";

export const analyticsRouter = createRouter({
  dashboard: publicQuery.query(() => getDashboardStats()),

  revenue: publicQuery
    .input(z.object({ days: z.number().default(7) }).optional())
    .query(({ input }) => getRevenueByDay(input?.days || 7)),

  bookingsByStatus: publicQuery.query(() => getBookingsByStatus()),
});
