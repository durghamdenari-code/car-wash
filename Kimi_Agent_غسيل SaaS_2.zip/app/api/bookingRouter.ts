import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findAllBookings,
  findBookingById,
  findRecentBookings,
  createBooking,
  updateBooking,
  assignWorker,
  getTodayBookingsCount,
  getPendingBookingsCount,
  getInProgressBookingsCount,
  getCompletedBookingsCount,
  getTotalRevenue,
  getTodayRevenue,
} from "./queries/bookings";

export const bookingRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        status: z.string().optional(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
      }).optional()
    )
    .query(({ input }) => {
      const dateFrom = input?.dateFrom ? new Date(input.dateFrom) : undefined;
      const dateTo = input?.dateTo ? new Date(input.dateTo) : undefined;
      return findAllBookings(input?.search, input?.status, dateFrom, dateTo);
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(({ input }) => findBookingById(input.id)),

  recent: publicQuery
    .input(z.object({ limit: z.number().default(10) }).optional())
    .query(({ input }) => findRecentBookings(input?.limit || 10)),

  create: publicQuery
    .input(
      z.object({
        bookingNumber: z.string().min(1),
        customerName: z.string().min(1),
        customerPhone: z.string().min(1),
        customerWhatsappId: z.string().optional(),
        carType: z.string().min(1),
        carModel: z.string().optional(),
        carColor: z.string().optional(),
        carPlate: z.string().optional(),
        address: z.string().optional(),
        lat: z.string().optional(),
        lng: z.string().optional(),
        serviceId: z.number(),
        servicePrice: z.string().min(1),
        totalAmount: z.string().min(1),
        scheduledDate: z.string().optional(),
        customerNotes: z.string().optional(),
        source: z.enum(["whatsapp", "app", "phone", "walk_in"]).optional(),
      })
    )
    .mutation(({ input }) => {
      const scheduledDate = input.scheduledDate
        ? new Date(input.scheduledDate)
        : undefined;
      return createBooking({ ...input, scheduledDate });
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum([
          "pending",
          "confirmed",
          "assigned",
          "in_progress",
          "completed",
          "cancelled",
          "no_show",
        ]).optional(),
        workerId: z.number().optional().nullable(),
        scheduledDate: z.string().optional(),
        startedAt: z.string().optional(),
        completedAt: z.string().optional(),
        paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]).optional(),
        paymentMethod: z.enum(["cash", "card", "wallet", "online"]).optional(),
        beforePhotos: z.array(z.string()).optional(),
        afterPhotos: z.array(z.string()).optional(),
        adminNotes: z.string().optional(),
        tipAmount: z.string().optional(),
      })
    )
    .mutation(({ input }) => {
      const { id, ...data } = input;
      const processed: any = { ...data };
      if (data.scheduledDate) processed.scheduledDate = new Date(data.scheduledDate);
      if (data.startedAt) processed.startedAt = new Date(data.startedAt);
      if (data.completedAt) processed.completedAt = new Date(data.completedAt);
      return updateBooking(id, processed);
    }),

  assign: publicQuery
    .input(z.object({ bookingId: z.number(), workerId: z.number() }))
    .mutation(({ input }) => assignWorker(input.bookingId, input.workerId)),

  stats: publicQuery.query(async () => {
    const [
      today,
      pending,
      inProgress,
      completed,
      totalRevenue,
      todayRevenue,
    ] = await Promise.all([
      getTodayBookingsCount(),
      getPendingBookingsCount(),
      getInProgressBookingsCount(),
      getCompletedBookingsCount(),
      getTotalRevenue(),
      getTodayRevenue(),
    ]);
    return {
      today,
      pending,
      inProgress,
      completed,
      totalRevenue,
      todayRevenue,
    };
  }),
});
