import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findAllLoyaltyMembers,
  findLoyaltyByPhone,
  findLoyaltyById,
  upsertLoyalty,
  redeemPoints,
  getLoyaltyStats,
} from "./queries/loyalty";

export const loyaltyRouter = createRouter({
  list: publicQuery
    .input(z.object({ search: z.string().optional() }).optional())
    .query(({ input }) => findAllLoyaltyMembers(input?.search)),

  getByPhone: publicQuery
    .input(z.object({ phone: z.string() }))
    .query(({ input }) => findLoyaltyByPhone(input.phone)),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(({ input }) => findLoyaltyById(input.id)),

  upsert: publicQuery
    .input(
      z.object({
        customerPhone: z.string().min(1),
        customerName: z.string().optional(),
        points: z.number().min(0),
        tier: z.enum(["bronze", "silver", "gold", "platinum"]).optional(),
        visits: z.number().optional(),
      })
    )
    .mutation(({ input }) => upsertLoyalty(input)),

  redeem: publicQuery
    .input(z.object({ id: z.number(), points: z.number().min(1) }))
    .mutation(({ input }) => redeemPoints(input.id, input.points)),

  stats: publicQuery.query(() => getLoyaltyStats()),
});
